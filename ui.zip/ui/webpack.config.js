/* eslint-disable react/destructuring-assignment */


/* eslint "react/react-in-jsx-scope": "off" */

/* eslint "react/jsx-no-undef": "off" */
/* eslint "no-alert": "off" */
/* eslint linebreak-style: ["error", "windows"] */
/* eslint no-restricted-globals: "off" */
const path = require('path');

module.exports = {
  mode: 'development',
  entry: './src/App.jsx',
  output: {
    filename: 'app.bundle.js',
    path: path.resolve(__dirname, 'public'),
  },
  module: {
    rules: [
      {
        test: /\.jsx?$/,
        use: 'babel-loader',
      },
    ],
  },
};

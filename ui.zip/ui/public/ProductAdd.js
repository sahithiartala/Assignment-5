/* eslint-disable react/destructuring-assignment */

/* eslint "react/react-in-jsx-scope": "off" */

/* globals React  */

/* eslint "react/jsx-no-undef": "off" */

/* eslint "no-alert": "off" */

/* eslint linebreak-style: ["error", "windows"] */

/* eslint no-restricted-globals: "off" */
export default class ProductAdd extends React.Component {
  constructor() {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
    this.state = {
      Price: '$'
    };
    this.handlepriceChange = this.handlepriceChange.bind(this);
  }

  handleSubmit(e) {
    e.preventDefault();
    const form = document.forms.productAdd;
    const product = {
      name: form.Product_Name.value,
      Price: form.Price.value.replace('$', ''),
      Image: form.Image_URL.value,
      category: form.category.value
    };
    this.props.createProduct(product);
    form.Product_Name.value = '';
    form.Price.value = '$';
    form.Image_URL.value = '';
    form.category.value = '';
  }

  handlepriceChange() {
    this.setState({
      Price: document.forms.productAdd.Price.value
    });
  }

  render() {
    return React.createElement("form", {
      name: "productAdd",
      onSubmit: this.handleSubmit
    }, React.createElement("div", {
      className: "wrapper_1"
    }, React.createElement("label", {
      htmlFor: "productname"
    }, "Product Name:", React.createElement("br", null), React.createElement("input", {
      type: "text",
      name: "Product_Name",
      placeholder: "Product Name",
      id: "productname"
    })), React.createElement("label", {
      htmlFor: "Price"
    }, "Price Per Unit", React.createElement("br", null), React.createElement("input", {
      type: "text",
      name: "Price",
      placeholder: "Price",
      id: "Price",
      defaultValue: this.state.Price,
      onChange: this.handlepriceChange
    })), React.createElement("br", null), React.createElement("button", {
      type: "submit"
    }, "Add Product")), React.createElement("div", {
      className: "wrapper_2"
    }, React.createElement("label", {
      htmlFor: "category"
    }, "Category", React.createElement("br", null), React.createElement("select", {
      name: "category",
      id: "category"
    }, React.createElement("option", {
      value: ""
    }, "Select your Category"), React.createElement("option", {
      value: "Shirts"
    }, "Shirts"), React.createElement("option", {
      value: "Jeans"
    }, "Jeans"), React.createElement("option", {
      value: "Jackets"
    }, "Jackets"), React.createElement("option", {
      value: "Sweaters"
    }, "Sweaters"), React.createElement("option", {
      value: "Accessories"
    }, "Accessories"))), React.createElement("br", null), React.createElement("label", {
      htmlFor: "ImageURL"
    }, "Image_URL", React.createElement("br", null), React.createElement("input", {
      type: "text",
      name: "Image_URL",
      placeholder: "URL",
      id: "ImageURL"
    })), React.createElement("br", null)));
  }

}
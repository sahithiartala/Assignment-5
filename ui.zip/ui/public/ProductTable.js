/* eslint-disable react/destructuring-assignment */

/* eslint "react/react-in-jsx-scope": "off" */

/* globals React */

/* eslint "react/jsx-no-undef": "off" */

/* eslint "no-alert": "off" */

/* eslint linebreak-style: ["error", "windows"] */

/* eslint no-restricted-globals: "off" */
export default function ProductTable(props) {
  {
    // eslint-disable-next-line max-len
    const productRows = props.products.map(product => React.createElement(ProductRow, {
      key: product.id,
      product: product
    }));
    return React.createElement("table", {
      className: "bordered-table"
    }, React.createElement("thead", null, React.createElement("tr", null, React.createElement("th", null, "Product Name"), React.createElement("th", null, "Category"), React.createElement("th", null, "Price"), React.createElement("th", null, "Image"))), React.createElement("tbody", null, productRows));
  }
}

function ProductRow(props) {
  {
    const {
      product
    } = props;
    return React.createElement("tr", null, React.createElement("td", null, product.name), React.createElement("td", null, product.category), React.createElement("td", null, product.Price), React.createElement("td", null, React.createElement("a", {
      href: product.Image,
      target: "blank"
    }, "View")));
  }
}
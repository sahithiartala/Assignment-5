/* eslint-disable react/destructuring-assignment */
/* eslint "react/react-in-jsx-scope": "off" */
/* globals React */
/* eslint "react/jsx-no-undef": "off" */
/* eslint "no-alert": "off" */
/* eslint linebreak-style: ["error", "windows"] */
/* eslint no-restricted-globals: "off" */

export default function ProductTable(props) {
  {
    // eslint-disable-next-line max-len
    const productRows = props.products.map(product => <ProductRow key={product.id} product={product} />);
    return (
      <table className="bordered-table">
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Image</th>
          </tr>
        </thead>
        <tbody>
          {productRows}
        </tbody>
      </table>
    );
  }
}

function ProductRow(props) {
  {
    const { product } = props;
    return (
      <tr>

        <td>{product.name}</td>
        <td>{product.category}</td>
        <td>{product.Price}</td>
        <td><a href={product.Image} target="blank">View</a></td>

      </tr>
    );
  }
}

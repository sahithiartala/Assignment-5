/* eslint-disable react/destructuring-assignment */
/* eslint "react/react-in-jsx-scope": "off" */
/* globals React ReactDOM */
/* eslint "react/jsx-no-undef": "off" */
/* eslint "no-alert": "off" */
/* eslint linebreak-style: ["error", "windows"] */
/* eslint no-restricted-globals: "off" */

import ProductList from './ProductList.jsx';

const element = <ProductList />;

ReactDOM.render(element, document.getElementById('contents'));
